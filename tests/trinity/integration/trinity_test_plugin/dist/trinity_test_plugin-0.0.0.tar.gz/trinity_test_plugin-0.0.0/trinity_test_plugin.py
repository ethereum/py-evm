from argparse import (
    ArgumentParser,
    Namespace,
    _SubParsersAction,
)

from trinity.config import (
    TrinityConfig,
)
from trinity.extensibility.plugin import BaseIsolatedPlugin

class TestPlugin(BaseIsolatedPlugin):

    def __init__(self):
        super().__init__()

    @property
    def name(self) -> str:
        return "TestPlugin"

    def configure_parser(self, arg_parser: ArgumentParser, subparser: _SubParsersAction) -> None:

        test_parser = subparser.add_parser('test')
        test_parser.set_defaults(func=self.run_console)

    def run_console(self, args: Namespace, trinity_config: TrinityConfig) -> None:
        print("works")

